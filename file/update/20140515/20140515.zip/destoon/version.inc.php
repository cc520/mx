<?php
define('DT_VERSION', '5.0');
define('DT_RELEASE', '20140515');
?>